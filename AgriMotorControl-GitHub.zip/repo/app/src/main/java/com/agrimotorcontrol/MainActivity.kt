package com.agrimotorcontrol

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.webkit.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val SMS_PERM = 101

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccessFromFileURLs = true
            allowUniversalAccessFromFileURLs = true
            setSupportZoom(false)
            displayZoomControls = false
            builtInZoomControls = false
            loadWithOverviewMode = true
            useWideViewPort = true
        }

        // Inject SMS bridge so JS can send real SMS
        webView.addJavascriptInterface(SmsBridge(), "AndroidSMS")
        webView.webViewClient = WebViewClient()
        webView.loadUrl("file:///android_asset/index.html")

        requestSmsPermissions()
    }

    inner class SmsBridge {
        @JavascriptInterface
        fun send(number: String, message: String) {
            try {
                SmsManager.getDefault().sendTextMessage(number, null, message, null, null)
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "✅ SMS Sent!", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "❌ SMS Failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun requestSmsPermissions() {
        val perms = listOf(Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS)
            .filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (perms.isNotEmpty())
            ActivityCompat.requestPermissions(this, perms.toTypedArray(), SMS_PERM)
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
