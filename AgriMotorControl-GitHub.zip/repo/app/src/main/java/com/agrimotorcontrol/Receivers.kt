package com.agrimotorcontrol

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.telephony.SmsManager

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != "android.provider.Telephony.SMS_RECEIVED") return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        for (m in msgs) {
            val from = m.originatingAddress ?: continue
            val body = m.messageBody ?: continue
            val prefs = ctx.getSharedPreferences("agri_prefs", Context.MODE_PRIVATE)
            val kit = prefs.getString("kitMobile", "") ?: continue
            val kitLast = kit.filter { it.isDigit() }.takeLast(10)
            val fromLast = from.filter { it.isDigit() }.takeLast(10)
            if (kitLast.isNotEmpty() && kitLast != fromLast) continue
            if (!body.startsWith("¿")) continue
            // Broadcast to WebView
            ctx.sendBroadcast(Intent("com.agrimotorcontrol.SMS").apply {
                putExtra("from", from); putExtra("message", body)
            })
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val cmd = intent.getStringExtra("command") ?: return
        val kit = ctx.getSharedPreferences("agri_prefs", Context.MODE_PRIVATE)
            .getString("kitMobile", "") ?: return
        if (kit.isEmpty()) return
        try { SmsManager.getDefault().sendTextMessage(kit, null, "¿1234${cmd}#", null, null) }
        catch (_: Exception) {}
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {}
}
